function setup() {
  // put setup code here
  createCanvas(480, 120);
}

function draw() {
  // put drawing code here
  background(204);
  line(20, 50, 420, 110);
}